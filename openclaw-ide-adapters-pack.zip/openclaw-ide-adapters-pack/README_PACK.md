# OpenClaw IDE Adapters Pack

Conteúdo:
- Cursor: `.cursorrules` e `.cursor/rules/openclaw.mdc`
- VS Code / Copilot: `.github/copilot-instructions.md`
- Google Antigravity: `GEMINI.md` (e também funciona com `AGENTS.md` se você preferir)
- OpenAI Codex: `AGENTS.md`
- Windsurf: `.windsurf/rules/openclaw.md`
- Qoder: `.qoder/rules/openclaw.md`
- Trae: regra para colar na UI (trae_rule.md)

Como integrar no seu repo:
1) Copie `templates/ide/<tool>/...` para dentro do seu `templates/ide/`.
2) Atualize `openclaw ide install` para perguntar quais adaptadores instalar.
3) Mantenha o padrão: PLAN -> CONSENT -> APPLY -> AUDIT.
