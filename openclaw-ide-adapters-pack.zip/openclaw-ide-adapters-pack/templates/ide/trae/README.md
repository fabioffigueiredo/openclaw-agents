# Trae adapter

Pelo que é público, o Trae Rules costuma ser aplicado via interface (colar regra), não via arquivo padronizado.

Use:
- `trae_rule.md` como texto para colar nas regras do Trae.

Se seu Trae suportar “rules from file”, aponte para este arquivo.
